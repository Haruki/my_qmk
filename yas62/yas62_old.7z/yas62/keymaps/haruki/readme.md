# The default keymap for bmc
